function addCaramel() {

}