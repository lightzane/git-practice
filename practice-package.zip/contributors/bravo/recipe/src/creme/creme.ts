function addCreme() {
    console.log('creme added!');
}