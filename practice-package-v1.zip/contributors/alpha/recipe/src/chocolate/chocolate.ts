function addChocolate() {
    console.log('adding chocolate');
    console.log('chocolate added!');
}